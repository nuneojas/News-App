package com.example.session16newsapp

object Constants {
    const val BASE_URL = "https://newsapi.org/v2/";
    const val API_KEY = "3bca45cd19454fcbab3e530a847ea261"
    const val US="us"

}